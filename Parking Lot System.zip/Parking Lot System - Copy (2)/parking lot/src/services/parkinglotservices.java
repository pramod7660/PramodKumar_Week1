package services;

import models.Vehicle;

public class parkinglotservices {
    public boolean parkVehicle(Vehicle v){
        System.out.println(v.getNumber()+" "+v.getVehicleType());
        return true;
    }
}
