package models;

public class Bike extends Vehicle{
    public Bike(String number,String vehicletype){
        super(number,vehicletype);
    }
}
