package models;

public class Truck extends Vehicle{
    public Truck(String number,String vehicletype){
        super(number,vehicletype);
    }
}
