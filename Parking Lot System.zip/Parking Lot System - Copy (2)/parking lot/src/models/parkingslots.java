package models;
public class parkingslots {
    boolean s1,s2,s3,s4,s5,s6;
}
