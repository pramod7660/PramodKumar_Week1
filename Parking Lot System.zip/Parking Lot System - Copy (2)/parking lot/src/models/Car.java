package models;

public class Car extends Vehicle{
    public Car(String number,String vehicletype){
        super(number,vehicletype);
    }
}
