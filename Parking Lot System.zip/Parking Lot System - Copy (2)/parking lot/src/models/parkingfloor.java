package models;

import java.util.ArrayList;
import java.util.List;

public class parkingfloor {
    private final List<parkingslots> parkingSlots = new ArrayList<>();

    public void addParkingSlot(parkingslots parkingSlot) {
        parkingSlots.add(parkingSlot);
    }

    public List<parkingslots> getParkingSlots() {
        return parkingSlots;
    }
}
