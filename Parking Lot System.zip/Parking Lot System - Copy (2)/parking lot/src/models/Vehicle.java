package models;

public class Vehicle {
    private String Number;
    private String vehicletype;

    public Vehicle(String number, String vehicletype) {
        this.Number = number;
        this.vehicletype = vehicletype;
    }

    public String getNumber() {
        return Number;
    }

    public String getVehicleType() {
        return vehicletype;
    }
}
