package models;

import java.util.ArrayList;
import java.util.List;

public class parkinglot {
    private final List<parkingfloor> parkingFloors = new ArrayList<>();

    public void addParkingFloor(parkingfloor parkingFloor) {
        parkingFloors.add(parkingFloor);
    }

    public List<parkingfloor> getParkingFloors() {
        return parkingFloors;
    }
}
