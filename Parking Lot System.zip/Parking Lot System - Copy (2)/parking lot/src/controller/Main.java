package controller;

import models.Bike;
import models.Car;
import models.Truck;
import services.parkinglotservices;

public class Main {
    public static void main(String args[]){
        parkinglotservices pls=new parkinglotservices();
        Bike b1=new Bike("AP-29-AU-1980","Bike");
        Bike b2=new Bike("AP-28-AU-1854","Bike");
        Bike b3=new Bike("TS-31-AU-4155","Bike");
        Bike b4=new Bike("TS-45-AU-1154","Bike");

        Car c1=new Car("TG-07-AZ-1122","Car");
        Car c2=new Car("TG-45-AZ-1515","Car");
        Car c3=new Car("TG-17-AZ-9415","Car");
        Car c4=new Car("TG-21-AZ-7151","Car");

        Truck t1=new Truck("AP-02-QE-1234","Truck");
        Truck t2=new Truck("AP-02-QE-1541","Truck");
        Truck t3=new Truck("AP-02-QE-4485","Truck");
        Truck t4=new Truck("AP-02-QE-4785","Truck");

        System.out.println(pls.parkVehicle(b1)?"Vehicle Parked":"Not Parked");
    }
}
